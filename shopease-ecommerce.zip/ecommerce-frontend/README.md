# ShopEase – E-commerce Web App

A full-stack e-commerce application built using React and Spring Boot.

## Features
- User Authentication
- Admin Product Management
- Cart & Checkout
- Order History

## Setup
- Backend: Spring Boot + MySQL
- Frontend: React